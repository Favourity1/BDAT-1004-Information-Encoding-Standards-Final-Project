﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProjectFinal
{
        public static class Constants
        {
            public const string Issuer = Audience;
            public const string Audience = "http://localhost:59381/";
            public const string key = "not_too_short_secret_otherwise_it_might_error";
        }
}
