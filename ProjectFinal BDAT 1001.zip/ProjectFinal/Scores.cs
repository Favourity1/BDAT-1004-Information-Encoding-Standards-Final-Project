﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Net.Http;
using System.Security.Claims;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace ProjectFinal
{
    public class Scores
    {
       static HttpClient client = new HttpClient();

    public IActionResult Index()
    {
        return View();
    }

       private IActionResult View(List<Scores> result)
        {
            throw new NotImplementedException();
        }

        [Authorize]
    public async Task<IActionResult> Secret()
    {
        var url = "https://run.mocky.io/v3/7b51438f-c26a-4db1-825a-f50d97433986";
        HttpResponseMessage response = await client.GetAsync(url);
        var result = new List<Scores>();

        if (response.IsSuccessStatusCode)
        {
            result = await JsonSerializer.DeserializeAsync<List<Scores>>(await response.Content.ReadAsStreamAsync()); //response.Content.ReadAsAsync<object>();
        }

        //return result;

        return View(result);
    }

    public IActionResult Authenticate()
    {

        var claims = new[]
       {
new Claim(JwtRegisteredClaimNames.Sub, "some_id"),
new Claim("grandpa","cookie")
};

        var secretBytes = Encoding.UTF8.GetBytes(Constants.key);

        var key = new SymmetricSecurityKey(secretBytes);

        var algorithm = SecurityAlgorithms.HmacSha256;

        var signingCredentials = new SigningCredentials(key, algorithm);

        var token = new JwtSecurityToken(
       Constants.Issuer,
       Constants.Audience,
       claims,
       notBefore: DateTime.Now,
       expires: DateTime.Now.AddHours(2),
       signingCredentials);

        var tokenJson = new JwtSecurityTokenHandler().WriteToken(token);

        return Ok(new { access_token = tokenJson });
    }

        private IActionResult Ok(object p)
        {
            throw new NotImplementedException();
        }
    }